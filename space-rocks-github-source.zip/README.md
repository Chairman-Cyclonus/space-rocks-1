# Space Rocks

A Godot 4.7.2 space shooter prepared for itch.io and GitHub Pages.

## Play and edit

Open `project.godot` with Godot 4.7.2 and press F5.
A/D rotate, W thrust, and Space shoots. Click the game to focus it in a browser.
This version uses keyboard controls.

## Export for itch.io

Install the matching export templates in Godot: Editor > Manage Export Templates.
With Python 3 installed, run from this folder:

```powershell
python tools/build_web.py --godot "C:/path/to/Godot_v4.7.2-stable_win64_console.exe"
```

If Godot is on PATH, use `python tools/build_web.py`.
The script creates `build/web/index.html` and `build/space-rocks-itch.zip`.
For a manual export, create the `build/web` folder, open Project > Export,
select Web, and export the project to `build/web/index.html`.

1. Create or edit an itch.io project and choose HTML as the kind of project.
2. Upload `build/space-rocks-itch.zip` and select "This file will be played in the browser".
3. Use an embedded viewport of 1152 by 648 and enable the fullscreen button.
4. Save and test the draft before publishing.

The ZIP contains index.html at its root. Upload the web ZIP, not the source ZIP.
The Compatibility renderer and disabled threads avoid special cross-origin header requirements.

To preview locally, run `python -m http.server 8000 --directory build/web`,
then visit http://localhost:8000. Do not double-click index.html.

## GitHub source repository

Put the CONTENTS of this folder at the repository root, including `.github`,
`.gitignore`, and `export_presets.cfg`. GitHub Desktop can add this folder as
an existing local repository (or create a repository here), then publish it.
The ignore file keeps generated caches and builds out of Git.
Original asset attributions are retained in `space_rocks_assets/assets/attributions.txt`.
No new license is assigned to your code or third-party assets by this setup.

The Build web game workflow builds on pushes to main/master and pull requests.
In GitHub Actions, download the `space-rocks-itch` artifact, unzip that artifact,
and upload the enclosed `space-rocks-itch.zip` to itch.io.

## Optional GitHub Pages hosting

1. In repository Settings > Pages, choose GitHub Actions as the source.
2. Open Actions > Build web game > Run workflow on your default branch.
3. Check "Publish this build to GitHub Pages" and run it.
4. Open the URL from the deploy job once complete.

Ordinary pushes only build; Pages is published when you select that manual option.
The workflow requires access to GitHub release downloads for Godot 4.7.2 and templates.

References: [Godot web export](https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_web.html),
[itch.io HTML5 uploads](https://itch.io/docs/creators/html5),
[GitHub Pages workflows](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).
